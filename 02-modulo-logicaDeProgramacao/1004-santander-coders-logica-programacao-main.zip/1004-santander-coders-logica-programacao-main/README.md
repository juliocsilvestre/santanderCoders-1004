Entrega das Listas
- Entregar em um único arquivo javascript com o nome da lista.
  
  Exemplo: lista-01

Enviar o link do github.


Sugestão:
Criar um repositório específico da nossa matérias criar a estrutura de pastas abaixo

- Listas
- Projeto Final

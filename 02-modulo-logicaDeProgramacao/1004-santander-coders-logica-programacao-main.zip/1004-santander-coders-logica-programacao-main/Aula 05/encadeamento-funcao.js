const texto = "hello world";
const resultado = texto
.toUpperCase()
//s.substring(0,5)
.replace("HELLO", "JAQUE");


console.log(resultado);
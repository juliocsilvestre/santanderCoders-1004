Crie uma função que calcule a soma de dois números.
Escreva uma função que calcule o produto de três números.
Crie uma função que verifique se um número é par ou ímpar.
Escreva uma função que inverta uma string (por exemplo, "hello" se torna "olleh").
Crie uma função que retorne o maior valor de um array de números.
Escreva uma função que calcule a média de um array de números.
Crie uma função que verifique se uma palavra é um palíndromo (lê-se igual de trás para frente).
Escreva uma função que conte quantas vezes uma determinada letra aparece em uma string.
Crie uma função que calcule o fatorial de um número.
Escreva uma função que converta graus Celsius para Fahrenheit.
Crie uma função que encontre o valor mínimo e máximo em um array de números.
Escreva uma função que calcule a sequência de Fibonacci até um determinado número de termos.
Crie uma função que verifique se um número é primo.
Escreva uma função que remova os elementos duplicados de um array.
Crie uma função que ordene um array de números em ordem crescente.
Escreva uma função que retorne o número de dias entre duas datas.
Crie uma função que calcule o raio de um círculo com base em sua área.
Escreva uma função que encontre o segundo maior valor em um array de números.
Crie uma função que converta um valor em dólares para outra moeda com base em uma taxa de câmbio.
Escreva uma função que verifique se duas strings são anagramas (contêm as mesmas letras, mas em ordens diferentes).
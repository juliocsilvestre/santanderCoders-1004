const dobrar = function(x) {
  return x * 2;
}

console.log(dobrar(4));
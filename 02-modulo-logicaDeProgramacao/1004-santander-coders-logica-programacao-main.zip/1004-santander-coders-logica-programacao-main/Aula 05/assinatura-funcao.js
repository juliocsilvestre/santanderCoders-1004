
/***
 * Função criada para somar dois números inteiros
 *@param {number} a - o primeiro numero a ser somado
 *@param {number} b - o segundo numero a ser somado
 *@returns {number} - O resultado da soma do parametro a e do parametro b
 */

 function somar(a,b) {
  return a+b;
}
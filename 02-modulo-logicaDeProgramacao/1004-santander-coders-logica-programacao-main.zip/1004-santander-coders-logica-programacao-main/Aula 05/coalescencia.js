const valorBaseCliente = undefined;
const valorDefault = " Esse campo é string";


const formatacao  = valorBaseCliente ?? valorDefault;

console.log(formatacao);
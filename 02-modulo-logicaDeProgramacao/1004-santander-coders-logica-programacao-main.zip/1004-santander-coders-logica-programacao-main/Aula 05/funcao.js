// definir uma uma  função

// export function
// export default funciton 


function nomeDaFuncao() {
  // codigo da função
  return "ola mundo";
}

const x =  nomefun => {
  console.log(par1, par2);
  return "ola arrow function";
}

const y = nomeDaFuncao();

const j = x(1,2)
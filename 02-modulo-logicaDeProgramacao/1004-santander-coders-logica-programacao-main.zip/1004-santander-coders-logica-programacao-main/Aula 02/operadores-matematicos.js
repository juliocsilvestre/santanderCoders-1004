
console.log("Exemplo de uso de funções nativas para operações matemáticas"
)

const num1 = 5;
const num2 = 10;

// Operações matemáticas usando funções nativas
const sum = num1 + num2;
const difference = num1 - num2;
const product = num1 * num2;
const quotient = num1 / num2;

console.log(sum);        // Saída: 15
console.log(difference);  // Saída: -5
console.log(product);    // Saída: 50
console.log(quotient);   // Saída: 0.5

// Operadores de Incremento

// Incrementar +
// Decrementar -
let contador  = 0 

contador --; 
console.log(contador--)
console.log(contador--)
console.log(contador--)
console.log(contador)
console.log(contador)
console.log(contador)

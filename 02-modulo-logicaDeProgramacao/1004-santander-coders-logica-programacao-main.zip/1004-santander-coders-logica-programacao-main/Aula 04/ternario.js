let idade = 14;


let categoria = idade < 18 ? "Menor de idade" : "Maior de idade";
console.log(categoria);


if(idade < 18) {
  console.log("menor de idade")
} else  { 
  console.log("maior de idade")
}

console.log( idade < 18 ? "Menor de idade" : "Maior de idade")
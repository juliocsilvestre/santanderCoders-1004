import { buscaSimples } from "./buscaSimples/busca";
import { soma } from "./buscaSimples/soma"

console.log(soma(1,2));
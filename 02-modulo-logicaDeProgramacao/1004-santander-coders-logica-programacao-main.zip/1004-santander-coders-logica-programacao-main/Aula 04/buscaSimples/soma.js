export function soma (valora, valorb) {
  return valora + valorb;
}
// For
// ele permite executar um bloco de código quantas vezes a minha condição permitir

// primeiro parametro váriavel contadora + a inicialização dessa variavel
// segundo parametro a condicional para o bloco de codigo acontecer
// terceiro parametro incremento da variavel contadora
for(let i = 0; i < 5; i++) {
  //console.log(i)
}

// o laço while ele executa um bloco de código repetidamente enquanto 
// uma condição especificada for verdeira 

let i = 0;
while(i < 5) {
  //console.log(i);
  i++;
}

// do while
// so que, garantimos que dentro do que escrevemos no do é executado pelo
// m,enos uma vez
// mesmo se a condição do while for FALSA desde o inicio

let j = 0;
do {
  console.log(j);
  j++;
} while(j < 5)